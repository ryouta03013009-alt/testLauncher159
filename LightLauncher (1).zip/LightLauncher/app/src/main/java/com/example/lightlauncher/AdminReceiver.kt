package com.example.lightlauncher

import android.app.admin.DeviceAdminReceiver
import android.content.Context
import android.content.Intent

class AdminReceiver : DeviceAdminReceiver() {
    override fun onDisableRequested(context: Context, intent: Intent): CharSequence =
        "無効にすると、このアプリをアンインストールできるようになり、制限が回避されます。"
}
