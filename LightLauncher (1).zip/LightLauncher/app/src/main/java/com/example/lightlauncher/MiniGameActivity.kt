package com.example.lightlauncher

import android.annotation.SuppressLint
import android.app.Activity
import android.os.Bundle
import android.webkit.WebView

class MiniGameActivity : Activity() {
    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        if (Prefs.isRestricted(this)) { finish(); return }
        val w = WebView(this)
        w.settings.javaScriptEnabled = true
        w.loadUrl("file:///android_asset/game.html")
        setContentView(w)
    }

    override fun onResume() {
        super.onResume()
        if (Prefs.isRestricted(this)) finish()
    }
}
