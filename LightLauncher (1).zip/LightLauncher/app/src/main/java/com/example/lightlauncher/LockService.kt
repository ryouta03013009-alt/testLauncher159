package com.example.lightlauncher

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.telecom.TelecomManager
import android.view.accessibility.AccessibilityEvent

class LockService : AccessibilityService() {
    companion object {
        var instance: LockService? = null
        private val PROTECTED = setOf(
            "com.android.settings",
            "com.google.android.packageinstaller",
            "com.android.packageinstaller",
            "com.samsung.android.packageinstaller"
        )
    }

    private val h = Handler(Looper.getMainLooper())
    private var lastPkg: String? = null

    // 5秒ごとに「今前面にいるアプリ」を再チェック(ゲーム中に制限時間が来た場合の対策)
    private val watch = object : Runnable {
        override fun run() {
            lastPkg?.let { if (blocked(it)) performGlobalAction(GLOBAL_ACTION_HOME) }
            h.postDelayed(this, 5000)
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        h.removeCallbacks(watch)
        h.post(watch)
    }

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        h.removeCallbacks(watch)
        return super.onUnbind(intent)
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent?) {
        if (e?.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = e.packageName?.toString() ?: return
        if (!neutral(pkg)) lastPkg = pkg
        if (blocked(pkg)) performGlobalAction(GLOBAL_ACTION_HOME)
    }

    /** システムUI・キーボードなどは前面アプリの判定に使わない */
    private fun neutral(pkg: String): Boolean {
        if (pkg == "com.android.systemui" || pkg == "android") return true
        return pkg == ime()
    }

    private fun ime() = Settings.Secure.getString(contentResolver, Settings.Secure.DEFAULT_INPUT_METHOD)
        ?.substringBefore('/')

    private fun allowed(pkg: String): Boolean {
        if (pkg == packageName || neutral(pkg)) return true
        val dialer = (getSystemService(TELECOM_SERVICE) as? TelecomManager)?.defaultDialerPackage
        return pkg == dialer
    }

    private fun blocked(pkg: String): Boolean {
        if (Prefs.isRestricted(this)) return !allowed(pkg)
        return Prefs.protect(this) && !Prefs.unlocked(this) && pkg in PROTECTED
    }

    override fun onInterrupt() {}
}
