package com.example.lightlauncher

import android.app.Activity
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast

class SettingsActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        askPass(this, { build() }, { finish() })
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun build() {
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(40), dp(16), dp(16))
        }
        fun label(t: String) = TextView(this).apply { text = t; setPadding(0, dp(12), 0, 0) }

        val sw = Switch(this).apply { text = "制限を有効にする"; isChecked = Prefs.enabled(this@SettingsActivity) }
        val prot = Switch(this).apply {
            text = "設定アプリ/インストーラーを常にパスワード保護"
            isChecked = Prefs.protect(this@SettingsActivity)
        }
        val win = EditText(this).apply { setText(Prefs.windows(this@SettingsActivity)) }
        val um = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER
            setText(Prefs.unlockMin(this@SettingsActivity).toString())
        }
        val pw = EditText(this).apply {
            hint = "空欄なら変更なし"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }

        col.addView(sw)
        col.addView(prot)
        col.addView(label("制限時間帯(例: 22:00-07:00,09:00-15:00)"))
        col.addView(win)
        col.addView(label("パスワード解除の有効時間(分)"))
        col.addView(um)
        col.addView(label("新しいパスワード(必ず設定してください)"))
        col.addView(pw)
        col.addView(Button(this).apply {
            text = "保存(時計の基準もリセット)"
            setOnClickListener {
                Prefs.save(context, sw.isChecked, win.text.toString(), um.text.toString().toIntOrNull() ?: 30)
                Prefs.putBool(context, "protect", prot.isChecked)
                if (pw.text.isNotEmpty()) Prefs.setPass(context, pw.text.toString())
                Toast.makeText(context, "保存しました", Toast.LENGTH_SHORT).show()
                finish()
            }
        })
        col.addView(Button(this).apply {
            text = "① アクセシビリティで「Light Launcher 制限」をON"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })
        col.addView(Button(this).apply {
            text = "② 標準ホームアプリに設定"
            setOnClickListener { startActivity(Intent(Settings.ACTION_HOME_SETTINGS)) }
        })
        col.addView(Button(this).apply {
            text = "③ 端末管理者をON(アンインストール防止)"
            setOnClickListener {
                startActivity(Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN)
                    .putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN,
                        ComponentName(context, AdminReceiver::class.java))
                    .putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION,
                        "アンインストール防止と画面オフに使います"))
            }
        })
        setContentView(ScrollView(this).apply { addView(col) })
    }
}
