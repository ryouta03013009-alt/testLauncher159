package com.example.lightlauncher

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.os.SystemClock
import android.text.InputType
import android.widget.EditText
import android.widget.Toast
import java.security.MessageDigest
import java.util.Calendar
import java.util.TimeZone
import kotlin.math.abs

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("p", Context.MODE_PRIVATE)
    private fun el() = SystemClock.elapsedRealtime()

    fun enabled(c: Context) = sp(c).getBoolean("enabled", true)
    fun windows(c: Context) = sp(c).getString("windows", "22:00-07:00")!!
    fun unlockMin(c: Context) = sp(c).getInt("unlockMin", 30)
    fun hasPass(c: Context) = sp(c).getString("hash", null) != null
    fun protect(c: Context) = sp(c).getBoolean("protect", false)
    fun tamper(c: Context) = sp(c).getBoolean("tamper", false)

    /** 設定保存時に時計の基準も取り直す(パスワード認証済みの操作) */
    fun save(c: Context, en: Boolean, w: String, um: Int) {
        sp(c).edit().putBoolean("enabled", en).putString("windows", w).putInt("unlockMin", um)
            .putBoolean("tamper", false).apply()
        anchor(c)
    }

    // ---------- パスワード ----------
    private fun hash(salt: String, pw: String) =
        MessageDigest.getInstance("SHA-256").digest((salt + pw).toByteArray())
            .joinToString("") { "%02x".format(it) }

    fun setPass(c: Context, pw: String) {
        val salt = System.nanoTime().toString()
        sp(c).edit().putString("salt", salt).putString("hash", hash(salt, pw)).apply()
    }

    /** 5回間違えると5分ロック */
    fun lockoutLeft(c: Context): Long {
        val e = el()
        val s = sp(c).getLong("los", 0L)
        val u = sp(c).getLong("lo", 0L)
        return if (e >= s && e < u) u - e else 0L
    }

    fun check(c: Context, pw: String): Boolean {
        val h = sp(c).getString("hash", null) ?: return true
        if (lockoutLeft(c) > 0) return false
        val ok = h == hash(sp(c).getString("salt", "")!!, pw)
        val f = sp(c).getInt("fails", 0) + 1
        if (ok) sp(c).edit().putInt("fails", 0).apply()
        else if (f >= 5) {
            val e = el()
            sp(c).edit().putInt("fails", 0).putLong("los", e).putLong("lo", e + 300000L).apply()
        } else sp(c).edit().putInt("fails", f).apply()
        return ok
    }

    // ---------- 一時解除(経過時間ベース。時計を戻しても延びない) ----------
    fun unlock(c: Context) {
        val e = el()
        sp(c).edit().putLong("us", e).putLong("ue", e + unlockMin(c) * 60000L)
            .putBoolean("tamper", false).apply()
        anchor(c)
    }

    fun unlocked(c: Context): Boolean {
        val e = el()
        return e >= sp(c).getLong("us", 0L) && e < sp(c).getLong("ue", 0L)
    }

    // ---------- 時刻改ざん検知 ----------
    private fun anchor(c: Context) {
        sp(c).edit().putLong("aw", System.currentTimeMillis()).putLong("ae", el())
            .putString("tzid", TimeZone.getDefault().id).apply()
    }

    private fun tampered(c: Context): Boolean {
        val s = sp(c)
        if (s.getBoolean("tamper", false)) return true
        val wall = System.currentTimeMillis()
        val e = el()
        val aw = s.getLong("aw", 0L)
        val ae = s.getLong("ae", 0L)
        if (aw == 0L || e < ae) { anchor(c); return false } // 初回 or 再起動
        val diff = abs((aw + (e - ae)) - wall)
        val tzChanged = s.getString("tzid", null) != TimeZone.getDefault().id
        if (diff > 60000 || tzChanged) { s.edit().putBoolean("tamper", true).apply(); return true }
        if (diff > 3000) anchor(c)
        return false
    }

    // ---------- 汎用 ----------
    fun set(c: Context, k: String): Set<String> = sp(c).getStringSet(k, emptySet())!!.toSet()
    fun toggle(c: Context, k: String, v: String): Boolean {
        val s = set(c, k).toMutableSet()
        val on = if (s.remove(v)) false else { s.add(v); true }
        sp(c).edit().putStringSet(k, s).apply()
        return on
    }
    fun str(c: Context, k: String, d: String) = sp(c).getString(k, d)!!
    fun putStr(c: Context, k: String, v: String) { sp(c).edit().putString(k, v).apply() }
    fun bool(c: Context, k: String, d: Boolean) = sp(c).getBoolean(k, d)
    fun putBool(c: Context, k: String, v: Boolean) { sp(c).edit().putBoolean(k, v).apply() }

    // ---------- 時間帯 ----------
    private val re = Regex("""\s*(\d{1,2}):(\d{2})\s*-\s*(\d{1,2}):(\d{2})\s*""")

    fun parse(w: String): List<Pair<Int, Int>> = w.split(",").mapNotNull { s ->
        val m = re.matchEntire(s) ?: return@mapNotNull null
        val g = m.groupValues
        Pair(g[1].toInt() * 60 + g[2].toInt(), g[3].toInt() * 60 + g[4].toInt())
    }

    fun isRestricted(c: Context): Boolean {
        if (!enabled(c)) return false
        if (tampered(c)) return true          // 時刻・タイムゾーンの変更を検知したらロック
        if (unlocked(c)) return false
        val cal = Calendar.getInstance()
        val now = cal.get(Calendar.HOUR_OF_DAY) * 60 + cal.get(Calendar.MINUTE)
        return parse(windows(c)).any { (s, e) -> if (s <= e) now in s until e else now >= s || now < e }
    }
}

/** パスワード入力ダイアログ。未設定なら即 onOk。 */
fun askPass(a: Activity, onOk: () -> Unit, onCancel: () -> Unit = {}) {
    if (!Prefs.hasPass(a)) { onOk(); return }
    val left = Prefs.lockoutLeft(a)
    if (left > 0) {
        Toast.makeText(a, "ロック中です。あと${left / 1000}秒", Toast.LENGTH_SHORT).show()
        onCancel(); return
    }
    val et = EditText(a).apply {
        inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
    }
    AlertDialog.Builder(a)
        .setTitle("パスワード")
        .setView(et)
        .setCancelable(false)
        .setPositiveButton("OK") { _, _ ->
            if (Prefs.check(a, et.text.toString())) onOk()
            else {
                val msg = if (Prefs.lockoutLeft(a) > 0) "5回間違えたので5分ロックします" else "違います"
                Toast.makeText(a, msg, Toast.LENGTH_SHORT).show()
                onCancel()
            }
        }
        .setNegativeButton("キャンセル") { _, _ -> onCancel() }
        .show()
}
