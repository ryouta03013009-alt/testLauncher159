package com.example.lightlauncher

import android.app.Activity
import android.app.ActivityManager
import android.app.AlertDialog
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ApplicationInfo
import android.graphics.Color
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.telecom.TelecomManager
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.GestureDetector
import android.view.Gravity
import android.view.MotionEvent
import android.view.ViewGroup.LayoutParams.MATCH_PARENT
import android.view.ViewGroup.LayoutParams.WRAP_CONTENT
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import kotlin.math.sqrt

class MainActivity : Activity(), SensorEventListener {
    data class App(val pkg: String, val label: String, val cat: String)

    private val h = Handler(Looper.getMainLooper())
    private var tab = "すべて"
    private var query = ""
    private var allApps: List<App> = emptyList()
    private var list: ListView? = null
    private var status: TextView? = null
    private var rootView: LinearLayout? = null
    private var torchOn = false
    private var lastShake = 0L
    private lateinit var gd: GestureDetector

    private val tick = object : Runnable {
        override fun run() { refreshStatus(); h.postDelayed(this, 30000) }
    }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        tab = Prefs.str(this, "tab", "すべて")
        gd = GestureDetector(this, object : GestureDetector.SimpleOnGestureListener() {
            override fun onDoubleTap(e: MotionEvent): Boolean { lockScreen(); return true }
        })
    }

    override fun onResume() {
        super.onResume()
        if (tab == "🔒") tab = "すべて"   // 隠しタブは戻ってきたら再ロック
        query = ""
        render()
        h.removeCallbacks(tick)
        h.postDelayed(tick, 30000)
        val sm = getSystemService(SENSOR_SERVICE) as SensorManager
        sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)?.let {
            sm.registerListener(this, it, SensorManager.SENSOR_DELAY_UI)
        }
    }

    override fun onPause() {
        super.onPause()
        h.removeCallbacks(tick)
        (getSystemService(SENSOR_SERVICE) as SensorManager).unregisterListener(this)
    }

    @Deprecated("launcher: ignore back")
    override fun onBackPressed() {}

    // ---------- helpers ----------
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun btn(t: String, f: () -> Unit) =
        Button(this).apply { text = t; setOnClickListener { f() } }

    private fun watch(et: EditText, f: (String) -> Unit) {
        et.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) { f(s?.toString() ?: "") }
        })
    }

    private fun dialer() = (getSystemService(TELECOM_SERVICE) as? TelecomManager)?.defaultDialerPackage

    @Suppress("DEPRECATION")
    private fun catOf(ai: ApplicationInfo): String {
        if (ai.flags and ApplicationInfo.FLAG_IS_GAME != 0) return "ゲーム"
        if (Build.VERSION.SDK_INT >= 26) {
            when (ai.category) {
                ApplicationInfo.CATEGORY_GAME -> return "ゲーム"
                ApplicationInfo.CATEGORY_SOCIAL -> return "SNS"
                ApplicationInfo.CATEGORY_AUDIO, ApplicationInfo.CATEGORY_VIDEO,
                ApplicationInfo.CATEGORY_IMAGE, ApplicationInfo.CATEGORY_NEWS -> return "エンタメ"
                ApplicationInfo.CATEGORY_PRODUCTIVITY, ApplicationInfo.CATEGORY_MAPS,
                ApplicationInfo.CATEGORY_ACCESSIBILITY -> return "ツール"
            }
        }
        return "他"
    }

    private fun loadApps() {
        val pm = packageManager
        allApps = pm.queryIntentActivities(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .filter { it.activityInfo.packageName != packageName }
            .map { App(it.activityInfo.packageName, it.loadLabel(pm).toString(), catOf(it.activityInfo.applicationInfo)) }
            .distinctBy { it.pkg }
            .sortedBy { it.label.lowercase() }
    }

    private fun visible(): List<App> {
        val hidden = Prefs.set(this, "hidden")
        val favs = Prefs.set(this, "favs")
        if (Prefs.bool(this, "minimal", false)) {
            val d = dialer()
            return allApps.filter { (it.pkg in favs || it.pkg == d) && it.pkg !in hidden }
        }
        val l = if (tab == "🔒") allApps.filter { it.pkg in hidden } else allApps.filter { it.pkg !in hidden }
        if (query.isNotBlank()) return l.filter { it.label.contains(query, true) }
        return when (tab) {
            "★" -> l.filter { it.pkg in favs }
            "ゲーム", "SNS", "エンタメ", "ツール", "他" -> l.filter { it.cat == tab }
            else -> l
        }
    }

    // ---------- UI ----------
    private fun render() {
        loadApps()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(12), dp(36), dp(12), dp(12))
        }
        rootView = root
        val st = TextView(this).apply {
            textSize = 12f
            setPadding(0, 0, 0, dp(8))
            setOnTouchListener { _, ev -> gd.onTouchEvent(ev); true }
        }
        status = st
        root.addView(st)

        val minimal = Prefs.bool(this, "minimal", false)
        if (!minimal) {
            val row = LinearLayout(this)
            listOf("メモ", "★", "すべて", "ゲーム", "SNS", "エンタメ", "ツール", "他", "🔒").forEach { t ->
                row.addView(Button(this).apply {
                    text = t; textSize = 12f; isAllCaps = false
                    alpha = if (t == tab) 1f else 0.55f
                    setOnClickListener {
                        if (t == "🔒") askPass(this@MainActivity, { setTab(t) }) else setTab(t)
                    }
                })
            }
            root.addView(HorizontalScrollView(this).apply { addView(row) })
        }
        if (!minimal && tab == "メモ") {
            val memo = EditText(this).apply {
                hint = "メモ・TODO"
                gravity = Gravity.TOP or Gravity.START
                inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
                setText(Prefs.str(this@MainActivity, "memo", ""))
            }
            watch(memo) { Prefs.putStr(this, "memo", it) }
            root.addView(memo, LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f))
        } else {
            if (!minimal) {
                val q = EditText(this).apply {
                    hint = "🔍 アプリ検索"
                    isSingleLine = true
                    setText(query)
                }
                watch(q) { query = it; updateList() }
                root.addView(q)
            }
            val lv = ListView(this)
            list = lv
            root.addView(lv, LinearLayout.LayoutParams(MATCH_PARENT, 0, 1f))
            updateList()
        }

        val acts = LinearLayout(this)
        val lp = { LinearLayout.LayoutParams(0, WRAP_CONTENT, 1f) }
        if (!minimal) {
            acts.addView(btn("ファイル") {
                startActivity(Intent.createChooser(
                    Intent(Intent.ACTION_GET_CONTENT).setType("*/*").addCategory(Intent.CATEGORY_OPENABLE), "ファイル"))
            }, lp())
            acts.addView(btn("ゲーム") { startActivity(Intent(this, MiniGameActivity::class.java)) }, lp())
        }
        acts.addView(btn(if (minimal) "ミニマルOFF" else "ミニマル") {
            Prefs.putBool(this, "minimal", !minimal); render()
        }, lp())
        acts.addView(btn("設定") { startActivity(Intent(this, SettingsActivity::class.java)) }, lp())
        root.addView(acts)

        setContentView(root)
        refreshStatus()
    }

    private fun setTab(t: String) {
        tab = t
        if (t != "🔒") Prefs.putStr(this, "tab", t)
        query = ""
        render()
    }

    private fun updateList() {
        val lv = list ?: return
        val items = visible()
        val favs = Prefs.set(this, "favs")
        lv.adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1,
            items.map { (if (it.pkg in favs) "★ " else "") + it.label })
        lv.setOnItemClickListener { _, _, i, _ ->
            packageManager.getLaunchIntentForPackage(items[i].pkg)?.let { startActivity(it) }
        }
        lv.setOnItemLongClickListener { _, _, i, _ -> menu(items[i]); true }
    }

    private fun menu(a: App) {
        val fav = a.pkg in Prefs.set(this, "favs")
        val hid = a.pkg in Prefs.set(this, "hidden")
        val shk = Prefs.str(this, "shakePkg", "") == a.pkg
        val items = arrayOf(
            if (fav) "★ お気に入り解除" else "★ お気に入りに追加",
            if (hid) "🔒 非表示を解除" else "🔒 非表示にする",
            if (shk) "📳 シェイク起動を解除" else "📳 シェイクで起動に設定")
        AlertDialog.Builder(this).setTitle(a.label).setItems(items) { _, w ->
            when (w) {
                0 -> Prefs.toggle(this, "favs", a.pkg)
                1 -> Prefs.toggle(this, "hidden", a.pkg)
                2 -> Prefs.putStr(this, "shakePkg", if (shk) "" else a.pkg)
            }
            updateList()
        }.show()
    }

    private fun refreshStatus() {
        val b = registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val lv = b?.getIntExtra("level", -1) ?: -1
        val sc = b?.getIntExtra("scale", 100) ?: 100
        val pct = if (lv >= 0 && sc > 0) lv * 100 / sc else -1
        val temp = (b?.getIntExtra("temperature", 0) ?: 0) / 10.0
        val mi = ActivityManager.MemoryInfo()
        (getSystemService(ACTIVITY_SERVICE) as ActivityManager).getMemoryInfo(mi)
        val gb = 1024.0 * 1024 * 1024
        status?.text = "%s  🔋%d%% %.1f℃  RAM %.1f/%.1fGB".format(
            SimpleDateFormat("HH:mm", java.util.Locale.getDefault()).format(Date()),
            pct, temp, mi.availMem / gb, mi.totalMem / gb)
        val hr = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        val bg = when {
            pct in 0..20 -> Color.rgb(74, 21, 21)
            hr in 5..9 -> Color.rgb(27, 58, 87)
            hr in 10..16 -> Color.rgb(24, 66, 58)
            hr in 17..19 -> Color.rgb(70, 45, 30)
            else -> Color.rgb(16, 16, 24)
        }
        rootView?.setBackgroundColor(bg)
    }

    // ---------- actions ----------
    private fun lockScreen() {
        val dpm = getSystemService(DEVICE_POLICY_SERVICE) as DevicePolicyManager
        if (dpm.isAdminActive(ComponentName(this, AdminReceiver::class.java))) dpm.lockNow()
        else Toast.makeText(this, "設定で「端末管理者」をONにしてください", Toast.LENGTH_SHORT).show()
    }

    override fun onSensorChanged(e: SensorEvent) {
        val g = sqrt(e.values[0] * e.values[0] + e.values[1] * e.values[1] + e.values[2] * e.values[2]) /
            SensorManager.GRAVITY_EARTH
        val now = System.currentTimeMillis()
        if (g > 2.7f && now - lastShake > 1500) { lastShake = now; onShake() }
    }

    override fun onAccuracyChanged(s: Sensor?, a: Int) {}

    private fun onShake() {
        val p = Prefs.str(this, "shakePkg", "")
        if (p.isNotEmpty()) {
            packageManager.getLaunchIntentForPackage(p)?.let { startActivity(it) }
            return
        }
        try {
            val cm = getSystemService(CAMERA_SERVICE) as CameraManager
            val id = cm.cameraIdList.firstOrNull {
                cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            } ?: return
            torchOn = !torchOn
            cm.setTorchMode(id, torchOn)
        } catch (_: Exception) {}
    }
}
