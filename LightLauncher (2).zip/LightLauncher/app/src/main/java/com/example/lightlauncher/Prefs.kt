package com.example.lightlauncher

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.os.SystemClock
import android.text.InputType
import android.widget.EditText
import android.widget.Toast
import java.security.MessageDigest

object Prefs {
    private fun sp(c: Context) = c.getSharedPreferences("p", Context.MODE_PRIVATE)
    private fun el() = SystemClock.elapsedRealtime()

    fun hasPass(c: Context) = sp(c).getString("hash", null) != null

    // ---------- パスワード(非表示アプリ・設定画面用) ----------
    private fun hash(salt: String, pw: String) =
        MessageDigest.getInstance("SHA-256").digest((salt + pw).toByteArray())
            .joinToString("") { "%02x".format(it) }

    fun setPass(c: Context, pw: String) {
        val salt = System.nanoTime().toString()
        sp(c).edit().putString("salt", salt).putString("hash", hash(salt, pw)).apply()
    }

    fun clearPass(c: Context) {
        sp(c).edit().remove("salt").remove("hash").apply()
    }

    /** 5回間違えると5分ロック */
    fun lockoutLeft(c: Context): Long {
        val e = el()
        val s = sp(c).getLong("los", 0L)
        val u = sp(c).getLong("lo", 0L)
        return if (e >= s && e < u) u - e else 0L
    }

    fun check(c: Context, pw: String): Boolean {
        val h = sp(c).getString("hash", null) ?: return true
        if (lockoutLeft(c) > 0) return false
        val ok = h == hash(sp(c).getString("salt", "")!!, pw)
        val f = sp(c).getInt("fails", 0) + 1
        if (ok) sp(c).edit().putInt("fails", 0).apply()
        else if (f >= 5) {
            val e = el()
            sp(c).edit().putInt("fails", 0).putLong("los", e).putLong("lo", e + 300000L).apply()
        } else sp(c).edit().putInt("fails", f).apply()
        return ok
    }

    // ---------- 汎用 ----------
    fun set(c: Context, k: String): Set<String> = sp(c).getStringSet(k, emptySet())!!.toSet()
    fun toggle(c: Context, k: String, v: String): Boolean {
        val s = set(c, k).toMutableSet()
        val on = if (s.remove(v)) false else { s.add(v); true }
        sp(c).edit().putStringSet(k, s).apply()
        return on
    }
    fun str(c: Context, k: String, d: String) = sp(c).getString(k, d)!!
    fun putStr(c: Context, k: String, v: String) { sp(c).edit().putString(k, v).apply() }
    fun bool(c: Context, k: String, d: Boolean) = sp(c).getBoolean(k, d)
    fun putBool(c: Context, k: String, v: Boolean) { sp(c).edit().putBoolean(k, v).apply() }
}

/** パスワード入力ダイアログ。未設定なら即 onOk。 */
fun askPass(a: Activity, onOk: () -> Unit, onCancel: () -> Unit = {}) {
    if (!Prefs.hasPass(a)) { onOk(); return }
    val left = Prefs.lockoutLeft(a)
    if (left > 0) {
        Toast.makeText(a, "ロック中です。あと${left / 1000}秒", Toast.LENGTH_SHORT).show()
        onCancel(); return
    }
    val et = EditText(a).apply {
        inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
    }
    AlertDialog.Builder(a)
        .setTitle("パスワード")
        .setView(et)
        .setCancelable(false)
        .setPositiveButton("OK") { _, _ ->
            if (Prefs.check(a, et.text.toString())) onOk()
            else {
                val msg = if (Prefs.lockoutLeft(a) > 0) "5回間違えたので5分ロックします" else "違います"
                Toast.makeText(a, msg, Toast.LENGTH_SHORT).show()
                onCancel()
            }
        }
        .setNegativeButton("キャンセル") { _, _ -> onCancel() }
        .show()
}
