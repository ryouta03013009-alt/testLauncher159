package com.example.lightlauncher

import android.app.admin.DeviceAdminReceiver

class AdminReceiver : DeviceAdminReceiver()
