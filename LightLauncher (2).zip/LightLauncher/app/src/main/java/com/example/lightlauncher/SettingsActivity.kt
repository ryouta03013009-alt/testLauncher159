package com.example.lightlauncher

import android.app.Activity
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.text.InputType
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class SettingsActivity : Activity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        askPass(this, { build() }, { finish() })
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun build() {
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(40), dp(16), dp(16))
        }
        fun label(t: String) = TextView(this).apply { text = t; setPadding(0, dp(12), 0, 0) }

        val pw = EditText(this).apply {
            hint = "空欄なら変更なし"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
        }
        col.addView(label("パスワード(非表示アプリ・この設定画面用)"))
        col.addView(pw)
        col.addView(Button(this).apply {
            text = "パスワードを保存"
            setOnClickListener {
                if (pw.text.isNotEmpty()) {
                    Prefs.setPass(context, pw.text.toString())
                    Toast.makeText(context, "保存しました", Toast.LENGTH_SHORT).show()
                    pw.setText("")
                }
            }
        })
        col.addView(Button(this).apply {
            text = "パスワードを削除"
            setOnClickListener {
                Prefs.clearPass(context)
                Toast.makeText(context, "削除しました", Toast.LENGTH_SHORT).show()
            }
        })
        col.addView(label("ホーム・端末設定"))
        col.addView(Button(this).apply {
            text = "標準ホームアプリに設定"
            setOnClickListener { startActivity(Intent(Settings.ACTION_HOME_SETTINGS)) }
        })
        col.addView(Button(this).apply {
            text = "端末管理者をON(ダブルタップで画面オフに使用)"
            setOnClickListener {
                startActivity(Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN)
                    .putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN,
                        ComponentName(context, AdminReceiver::class.java))
                    .putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION,
                        "ダブルタップで画面をオフにするために使います"))
            }
        })
        setContentView(ScrollView(this).apply { addView(col) })
    }
}
